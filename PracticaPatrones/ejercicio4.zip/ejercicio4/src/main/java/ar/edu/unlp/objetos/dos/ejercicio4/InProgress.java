package ar.edu.unlp.objetos.dos.ejercicio4;

public class InProgress extends State{

}
