package ar.edu.unlp.objetos.dos.ejercicio4;

import java.time.LocalDate;

public class Finished extends State{
	
}
