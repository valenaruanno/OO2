package ar.edu.unlp.objetos.dos.ejercicio4;

public class Paused extends State{

}
