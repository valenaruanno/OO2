package ar.edu.unlp.objetos.dos.ejercicio4;

public class State {

	public void start() {
		// TODO Auto-generated method stub
		
	}

	public void togglePaused() {
		// TODO Auto-generated method stub
		
	}

	public void finish() {
		// TODO Auto-generated method stub
		
	}

}
