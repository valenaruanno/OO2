package ar.edu.unlp.objetos.dos.ejercicio4;

import java.time.Duration;
import java.time.LocalDate;

public class ToDoItem {
	private String name;
	private State state;
	private String comment;
	private LocalDate inicio;
	private LocalDate fin;
	
	public ToDoItem(String name) {
		this.name = name;
		this.state = new Pending();
	}
	
	protected void setState(State state) {
		this.state = state;
	}
	
	public void Start() {
		this.state.start();
		this.inicio = LocalDate.now();
		
	}
	
	public void togglePaused() {
		this.state.togglePaused();
	}
	
	public void finish() {
		this.state.finish();
	}
	
	public Duration workedTime() {
		this.state.workedTime();
	}
	
}
